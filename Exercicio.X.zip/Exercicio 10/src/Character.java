
public abstract class Character {
	
	WeaponBehavior weaponBehavior;

	abstract void fight();
}
