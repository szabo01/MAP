package exercicio.v;

public class PizzaNY {
	public String tamanho;
	

}
