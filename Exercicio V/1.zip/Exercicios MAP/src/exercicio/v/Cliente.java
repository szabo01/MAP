package exercicio.v;

public class Cliente {

}
