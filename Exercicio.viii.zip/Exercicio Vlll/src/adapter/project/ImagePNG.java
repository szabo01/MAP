package adapter.project;

public class ImagePNG implements Image{

	@Override
	public void desenhar(int pontoX, int pontoY, int altura, int largura) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String carregar(String arquivo, String extensao) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
